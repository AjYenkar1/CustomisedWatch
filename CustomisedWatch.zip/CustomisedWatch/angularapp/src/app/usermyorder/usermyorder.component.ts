import { Component } from '@angular/core';
import { AppService } from 'app.service';
import { UserdataserviceService } from '../service/userdataservice.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-usermyorder',
  templateUrl: './usermyorder.component.html',
  styleUrls: ['./usermyorder.component.css']
})
export class UsermyorderComponent {
//   order:any
//     constructor(private appservice:AppService){

//         appservice.order().subscribe((data: any)=>{
  
//         console.log("data",data);
  
//         this.order=data;
  
//       });
// }
//   deleteorder(data:any){

//       this.appservice.deleteorder(data).subscribe((result)=>{
    
//         console.warn(result)
    
    
    
    
//       })
//   }
    pro:any;
    giftId:any;
    giftName:string='';
    giftPrice:string='';
    giftDetails:string='';
    constructor(private user:UserdataserviceService,private router:Router){
      this.giftId=sessionStorage.getItem('giftId');
      console.log(this.giftId);

      user.getGift(this.giftId).subscribe((data)=>{
        console.log("data",data);
        this.pro=data;
        console.log(this.pro);
        
        
      })
      
    }
}
