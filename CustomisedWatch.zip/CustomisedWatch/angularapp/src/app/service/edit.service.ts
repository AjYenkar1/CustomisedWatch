import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class EditService {
  edit:any;
  constructor(private editdata:EditService){
 
  }
}