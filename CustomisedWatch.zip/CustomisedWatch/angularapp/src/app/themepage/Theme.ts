export class Theme{
    themeId:number=0;
    themeName:string='';
    themeDetails:string='';
    themePrice:number;
    gift:any;
    constructor(themeId:number ,themeName:string,themeDetails:string,themePrice:number, gift:any) 
		{
		this.themeId = themeId;
		this.themeName = themeName;
		this.themeDetails = themeDetails;
		this.themePrice = themePrice;
		this.gift = gift;
        }
}