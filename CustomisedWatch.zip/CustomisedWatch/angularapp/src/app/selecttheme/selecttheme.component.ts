import { Component } from '@angular/core';
import { UserdataserviceService } from '../service/userdataservice.service';

@Component({
  selector: 'app-selecttheme',
  templateUrl: './selecttheme.component.html',
  styleUrls: ['./selecttheme.component.css']
})
export class SelectthemeComponent {
  
  alltheme: any;
  theme:any;
  themeId:any;
  
    constructor(private service:UserdataserviceService){
    
  
     service.them().subscribe((data: any)=>{
     console.log("data",data);
     this.theme=data;
     });
    
    }
  
  
  adduserorder(data:any){
    console.warn(data);
    this.service.addorder(data).subscribe((result)=>{
   console.warn(result)
  console.log(data);
  
  
   })
  
  }

  themeid:any;


  addtheme(themeId:any){
    this.themeid=themeId;
  console.log(this.themeid);
  sessionStorage.setItem("themeId",this.themeid);
  
  }
  add(){
    alert("order succesfully");
  }
  


}
