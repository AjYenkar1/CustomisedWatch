export class Order{
    orderId:number;
    orderName:string;
    orderDescription:string;
    orderDate:any;
    orderPrice:number;
    orderAddress:string;
    orderPhone:string;
    orderEmail:string;
    quantity:string;gift:any;
    theme:any;
    constructor(orderId:number,orderName:string,orderDescription:string,orderDate:any,orderPrice:number,
        orderAddress:string, orderPhone:string, orderEmail:string,quantity:string,gift:any,theme:any) {
    
    this.orderId = orderId;
    this.orderName = orderName;
    this.orderDescription = orderDescription;
    this.orderDate = orderDate;
    this.orderPrice = orderPrice;
    this.orderAddress = orderAddress;
    this.orderPhone = orderPhone;
    this.orderEmail = orderEmail;
    this.quantity = quantity;
    this.gift = gift;
    this.theme = theme;
}
}