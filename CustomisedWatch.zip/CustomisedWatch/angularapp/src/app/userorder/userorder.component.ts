import { Component } from '@angular/core';
import { UserdataserviceService } from '../service/userdataservice.service';
//import { AppService } from 'app.service';


@Component({
  selector: 'app-userorder',
  templateUrl: './userorder.component.html',
  styleUrls: ['./userorder.component.css']
})
export class UserorderComponent {

alltheme: any;
theme:any;
giftId:any;
themeId:any;
prodobj:any;
themeobj:any;
  constructor(private service:UserdataserviceService){
    
    this.giftId=sessionStorage.getItem('giftId');
    this.themeId=sessionStorage.getItem('themeId');
    console.log(this.giftId);
    console.log(this.themeId);
    
    service.getGift(this.giftId).subscribe((data)=>{
        console.log("data",data);
        this.prodobj=data;

        
        
        
    });
    
    
    service.gettheme(this.themeId).subscribe((data)=>{
      console.log("data",data);
      this.themeobj=data;
         
  });
   service.them().subscribe((data: any)=>{
   console.log("data",data);
   this.theme=data;
   });
  
   
  }


adduserorder(data:any){
  console.warn(data);
  this.service.addorder(data).subscribe((result)=>{
 console.warn(result);
 
 });

}

// total():number {
//   let c=0;
//  let a=parseInt(this.prodobj.giftPrice);
//  let b=parseInt(this.themeobj.themePrice);
//   c=a+b;
//  return c;
// }

// add(data:any){

//   alert("order succesfully");
//   console.warn(data);
//   this.service.addorder(data).subscribe((result)=>{
//  console.warn(result)


// }


// calculate(val1:number,val2:number){
//   this.cal=val1+val2

// }


}














