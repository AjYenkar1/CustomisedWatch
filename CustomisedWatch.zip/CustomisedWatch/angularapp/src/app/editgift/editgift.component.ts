import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AppService } from 'app.service';
export class GiftModel{
  editForm!:FormGroup;
  giftId: any;
  giftName: any;
  giftDetails: any;
  giftPrice: any;

  pro:any;

}

@Component({
  selector: 'app-editgift',
  templateUrl: './editgift.component.html',
  styleUrls: ['./editgift.component.css']
})
export class EditgiftComponent  implements OnInit {
  editForm!:FormGroup;
  giftId: any;
  giftName: any;
  giftDetails: any;
  giftPrice: any;
 
  pro:any;
    
  constructor(
  private formBuilder: FormBuilder,
  public addpolicy: AppService,private router:Router
   ) 
   { 
    this.giftId=sessionStorage.getItem('giftId');
   console.log(this.giftId);

   addpolicy.getGift(this.giftId).subscribe((data)=>{
     console.log("data",data);
     this.pro=data;
     console.log(this.pro);
     
     
   })
   }

   ngOnInit(){
    this.editForm = this.formBuilder.group({
      giftId:[''],
      giftName: ['', Validators.required],
      giftDetails: ['', Validators.required],
      giftPrice: ['', Validators.required],

       });
}
onSubmit(data:any): void {

  this.addpolicy.updategift(data.giftId,data).subscribe(res => {
  console.log(res);
     });
     alert("updated");
    }


      // updategift(gifts :{giftName:string,giftPrice:number,giftDetails:string,giftimageUrl:string}){
      //  if(!this.editModel)
      //  this.addpolicy.creategift(gifts);
      //  else 
      //   this.addpolicy.updategift()
      //       }

}
// public editgift(){
//   editdata.getEdit().subscribe((users:any)=>{
//     console.log("users",users);
  //   this.users=users
  // });}
