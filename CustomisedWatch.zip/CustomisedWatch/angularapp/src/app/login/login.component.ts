import { Component, OnInit } from '@angular/core';
import { AbstractControl, FormControl, FormGroup, Validators } from '@angular/forms';
import { UserService } from '../service/user.service';
import { UserLogin } from '../userLogin';
import { Router } from '@angular/router';
import { passwordMatch } from 'src/validation/passwordmatch';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
})
export class LoginComponent  {
  
  message:any;
  
  title = 'reactive-form';

 

  integreRegex = /^\d+$/

  emailRegex = /(?:[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*|"(?:[\x01-\x08\x0b\x0c\x0e-\x1f\x21\x23-\x5b\x5d-\x7f]|\\[\x01-\x09\x0b\x0c\x0e-\x7f])*")@(?:(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?|\[(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?|[a-z0-9-]*[a-z0-9]:(?:[\x01-\x08\x0b\x0c\x0e-\x1f\x21-\x5a\x53-\x7f]|\\[\x01-\x09\x0b\x0c\x0e-\x7f])+)\])/
registerForm = new FormGroup({

   

  username : new FormControl("", [Validators.required, Validators.maxLength(32)]),


  


  mobileNumber : new FormControl("", [Validators.required, Validators.minLength(10), Validators.maxLength(10), Validators.pattern(this.integreRegex)]),

    email : new FormControl("", [Validators.required, Validators.maxLength(32), Validators.pattern(this.emailRegex)]),

    password : new FormControl("", [Validators.required, Validators.maxLength(32), Validators.minLength(8)]),


    confirm_password : new FormControl("", [Validators.required, Validators.maxLength(32), Validators.minLength(8)]),


  }, [ passwordMatch("password", "confirm_password") ])
getControl(name: any): AbstractControl | null {

    return this.registerForm.get(name)

  }
  registerFn(){

    console.log(this.registerForm.value)

  }
  constructor(private user:UserService){}
  public registerNow() {

     let resp = this.user.doRegestration(this.registerForm.value);
    
     alert("signup is successfull")
    
    resp.subscribe((data) => {
    
     this.message = data;
    
   });
    
    }

}