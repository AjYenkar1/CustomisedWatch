export class UserLogin {
  constructor(
    username: string,
    email: string,
    mobileNumber: number,
    password: string,
    cnfPassword: string
  )  {}
}
