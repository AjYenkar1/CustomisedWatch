package com.example.Customizewatch.Controller;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.Customizewatch.Model.Gift;
import com.example.Customizewatch.Model.Login;
import com.example.Customizewatch.Model.Order;
import com.example.Customizewatch.Model.Theme;
import com.example.Customizewatch.Service.AdminService;
import com.example.Customizewatch.Service.UserService;




@RestController
@RequestMapping("/admin")
@CrossOrigin(origins="http://localhost:4200")
public class Admin {

	@Autowired
	private AdminService service;
	
	@Autowired
	private UserService userservice;
	
	@PostMapping("/login")
	public boolean AddAdmin(@RequestBody Login login ) {
		return service.addadmin(login);
	}
	
	@PostMapping("/addTheme")
	public Theme addTheme(@RequestBody Theme theme) {
		return service.addTheme(theme);
	}
    @GetMapping("/getTheme")
    public List<Theme> getTheme(){
    	return service.getTheme();
    	}
    @GetMapping("/getTheme/{themeId}")
    public Theme getthemebyid(@PathVariable ("themeId") int themeId) {
    	return service.getthemebyid(themeId);
    }
    @PutMapping("/editTheme/{themeId}")
    public Theme EditTheme(@RequestBody Theme theme,@PathVariable("themeId") int themeId)
    {
    	return service.editTheme(theme);
    }
    @DeleteMapping("/deleteTheme/{themeId}")
    public void DeleteTheme(@PathVariable int themeId)
    {
     service.deletetheme(themeId);
    }
    @PostMapping("/addGift")
    public Gift AddGift(@RequestBody Gift gift)
    {
    	return service.addGift(gift);
    }
    @GetMapping("/getGift")
    public List<Gift> viewGift()
    {
    	return service.ViewGift();
    }
    @GetMapping("/getGift/{giftId}")
    public Gift editGift(@PathVariable ("giftId") int giftId) {
    	return service.editgift(giftId);
    }
    @PutMapping("/editGift/{giftId}")
    public Gift EditGift(@RequestBody Gift gift,@PathVariable int giftId)
    {
    	return service.editgift(gift);
    }
    @DeleteMapping("/deleteGift/{giftId}")
    public void Deletegift(@PathVariable int giftId)
    {
     service.deletegift(giftId);
    }
    @GetMapping("/getAllOrders")
    public List<Order> ViewOrders()
    {
    	return userservice.vieworder();
    }
    @PutMapping("/editOrder/{orderId}")
    public Order EditOrders(@RequestBody Order order,@PathVariable int orderId)
    {
   	return userservice.editorder(order);
   }
    @DeleteMapping("/deleteOrder/{orderId}")
    public void deleteOrder(@PathVariable("orderId") int orderId)
    {
    	 userservice.deleteorder(orderId); 
    }
}

	

